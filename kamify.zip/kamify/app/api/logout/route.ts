import { NextRequest, NextResponse } from "next/server";
import { COOKIE } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const res = NextResponse.redirect(new URL("/entrar", req.url), 303);
  res.cookies.delete(COOKIE);
  return res;
}
